package com.ssafy.util;

public class SizeConstant {

	public final static int LIST_SIZE = 20;
	public final static int NAVIGATION_SIZE = 10;
	
}
